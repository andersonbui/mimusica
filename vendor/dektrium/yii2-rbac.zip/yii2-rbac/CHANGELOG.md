# CHANGELOG

## v0.3.0 [30 March 2016]

- Added admin access via rbac permission #54 (Talwoasc)
- Updated translations

## v0.2.0 [05 December 2015]

- Some fixes and improvements

## v0.1.0 [14 June 2015]

- Initial release
